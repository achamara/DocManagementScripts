var no_cover = ".res/nocover.jpg";

var is_valid_image = function(jsonObj, ref_obj){

  if( undefined == jsonObj || ref_obj == undefined || jsonObj[0] == undefined){
    return no_cover;
}

  if ($.isArray(jsonObj) && jsonObj.length >0){
      return ref_obj.category + "/" + ref_obj.name + "/"+ jsonObj[0];
  }

}
var replace_text = function(text, text_to_replace, value_to_replace, objecr_ref) {


    if (text_to_replace == "##COVER##") {
        return text.replace(text_to_replace.trim(), is_valid_image(value_to_replace, objecr_ref) );
    }

    if("##IS_DUPLICATE##" == text_to_replace){
      if ( value_to_replace== true){
      return text.replace(text_to_replace.trim(), "DUPLICATE");
    }else {
      return text.replace(text_to_replace.trim(), "");
    }

    }

    if (undefined == value_to_replace) {
        value_to_replace = "";
    }
    return text.replace(text_to_replace.trim(), value_to_replace);
}


$(document).ready(function() {

	if ( undefined == config_data.db_file_path || '###' == config_data.db_file_path ){
		alert('DB file location is not set, exiting!');
		return;
	}
	
	document.title =  config_data.file_title ;

    var image_tag = "<img class='cover' index='##DB_ID##' alt='##TITLE##' src='##COVER##' />";
    var title_tag = "<span class='title' index='##DB_ID##'>##TITLE##</span>";
    var text_tag = "<span class='text' index='##DB_ID##'>##TEXT##</span>";
    var duplicate_tag = "<span class='isDuplicate'>##IS_DUPLICATE##</span>"

    $.getJSON(config_data.db_file_path, function(data) {

        $.each(data.docs, function(index, doc_object) {
            $('.centered_div').append('<br/>');
            $('.centered_div').append($('<div/>').addClass("container").append(replace_text(replace_text(replace_text(image_tag, "##DB_ID##", index), "##TITLE##", doc_object.name), "##COVER##", doc_object.cover_image, doc_object)));
            $('.centered_div').append(replace_text(replace_text(title_tag, "##DB_ID##", index), "##TITLE##", doc_object.name));
            $('.centered_div').append( replace_text(duplicate_tag,  "##IS_DUPLICATE##", doc_object.duplicate_found));
            $('.centered_div').append(replace_text(replace_text(replace_text(text_tag, "##DB_ID##", index), "##TITLE##", doc_object.name), "##TEXT##", doc_object.description));
            $('.centered_div').append('<br/>');
        });

    });

});
